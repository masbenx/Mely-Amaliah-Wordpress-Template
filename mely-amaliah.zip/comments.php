<?php /*
				<!-- grab comments on single pages -->
				<div class="comments">
					<!-- You can start editing here. -->
					<h3 id="comments">There's <?php comments_number( 'no respond', '1 respond', '% responds' ); ?> to “<?php the_title(); ?>”</h3>
						<div class="navigation">
							<div class="alignleft"></div>
							<div class="alignright"></div>
						</div>
						<ol class="commentlist">
							<li class="comment byuser comment-author-mikemcalister bypostauthor even thread-even depth-1 parent" id="comment-6">
								<div id="div-comment-6" class="comment-body">
									<div class="comment-author vcard">
										<img alt="" src="Dispatch%20WordPress%20Theme%20%C2%BB%20The%20World%20Was%20Waiting%20Just%20For%20You_files/0aeecce7f483aa2b409fe65c352d034a.jpeg" class="avatar avatar-32 photo" height="32" width="32">
										<cite class="fn"><a href="http://mikemcalister.com/" rel="external nofollow" class="url">Mike McAlister</a></cite>
										<span class="says">says:</span>
									</div>
									<div class="comment-meta commentmetadata">
										<a href="http://okaythemes.com/dispatch/?p=13#comment-6">July 17, 2011 at 11:11 am</a>
									</div>
									
									<p>That was always the difference between Muhammad Ali and the rest of us. He came, he saw, and if he didn’t entirely conquer – he came as close as anybody we are likely to see in the lifetime of this doomed generation.</p>
	
									<div class="reply">
										<a class="comment-reply-link" href="http://okaythemes.com/dispatch/?p=13&amp;replytocom=6#respond" onclick='return addComment.moveForm("div-comment-6", "6", "respond", "13")'>Reply</a>
									</div>
								</div>
								<ul class="children">
									<li class="comment odd alt depth-2 parent" id="comment-43">
										<div id="div-comment-43" class="comment-body">
											<div class="comment-author vcard">
												<img alt="" src="Dispatch%20WordPress%20Theme%20%C2%BB%20The%20World%20Was%20Waiting%20Just%20For%20You_files/1543ac6e1ec3fac6815df2286e8be2e8.png" class="avatar avatar-32 photo" height="32" width="32">
												<cite class="fn"><a href="http://joss.com/" rel="external nofollow" class="url">joss</a></cite>
												<span class="says">says:</span>
											</div>
											<em class="comment-awaiting-moderation">Your comment is awaiting moderation.</em>
											<br>
											<div class="comment-meta commentmetadata">
												<a href="http://okaythemes.com/dispatch/?p=13#comment-43">August 22, 2011 at 7:29 am</a>
											</div>
											<p>tes the reply</p>
											<div class="reply">
												<a class="comment-reply-link" href="http://okaythemes.com/dispatch/?p=13&amp;replytocom=43#respond" onclick='return addComment.moveForm("div-comment-43", "43", "respond", "13")'>Reply</a>
											</div>
										</div>
										<ul class="children">
											<li class="comment even depth-3" id="comment-45">
												<div id="div-comment-45" class="comment-body">
													<div class="comment-author vcard">
														<img alt="" src="Dispatch%20WordPress%20Theme%20%C2%BB%20The%20World%20Was%20Waiting%20Just%20For%20You_files/1543ac6e1ec3fac6815df2286e8be2e8.png" class="avatar avatar-32 photo" height="32" width="32">
														<cite class="fn"><a href="http://joss.com/" rel="external nofollow" class="url">joss</a></cite>
														<span class="says">says:</span>
													</div>
													<em class="comment-awaiting-moderation">Your comment is awaiting moderation.</em>
													<br>
													<div class="comment-meta commentmetadata">
														<a href="http://okaythemes.com/dispatch/?p=13#comment-45">August 22, 2011 at 7:30 am</a>
													</div>
													<p>reply again</p>
													<div class="reply">
														<a class="comment-reply-link" href="http://okaythemes.com/dispatch/?p=13&amp;replytocom=45#respond" onclick='return addComment.moveForm("div-comment-45", "45", "respond", "13")'>Reply</a>	
													</div>
												</div>
											</li>
										</ul>
									</li>
								</ul>
							</li>
							<li class="comment odd alt thread-odd thread-alt depth-1" id="comment-44">
								<div id="div-comment-44" class="comment-body">
									<div class="comment-author vcard">
										<img alt="" src="Dispatch%20WordPress%20Theme%20%C2%BB%20The%20World%20Was%20Waiting%20Just%20For%20You_files/1543ac6e1ec3fac6815df2286e8be2e8.png" class="avatar avatar-32 photo" height="32" width="32">
										<cite class="fn"><a href="http://joss.com/" rel="external nofollow" class="url">joss</a></cite>
										<span class="says">says:</span>	
									</div>
									<em class="comment-awaiting-moderation">Your comment is awaiting moderation.</em>
									<br>
									<div class="comment-meta commentmetadata">
										<a href="http://okaythemes.com/dispatch/?p=13#comment-44">August 22, 2011 at 7:29 am</a>
									</div>
									<p>test the comment</p>
									<div class="reply">
										<a class="comment-reply-link" href="http://okaythemes.com/dispatch/?p=13&amp;replytocom=44#respond" onclick='return addComment.moveForm("div-comment-44", "44", "respond", "13")'>Reply</a>
									</div>
								</div>
							</li>
						</ol>
					</div>
					<div id="respond">
						<h3>Leave a Reply</h3>
						<div id="cancel-comment-reply">
							<small><a rel="nofollow" id="cancel-comment-reply-link" href="http://okaythemes.com/dispatch/?p=13#respond" style="display: none;">Click here to cancel reply.</a></small>
						</div>
						<form action="http://okaythemes.com/dispatch/wp-comments-post.php" method="post" id="commentform">
							<p>
								<input name="author" id="author" value="joss" size="22" tabindex="1" aria-required="true" type="text">
								<label for="author"><small>Name (required)</small></label>
							</p>
							<p>
								<input name="email" id="email" value="joss@joss.com" size="22" tabindex="2" aria-required="true" type="text">
								<label for="email"><small>Mail (will not be published) (required)</small></label>
							</p>
							<p>
								<input name="url" id="url" value="http://joss.com" size="22" tabindex="3" type="text">
								<label for="url"><small>Website</small></label>
							</p>
							<!--<p><small><strong>XHTML:</strong> You can use these tags: <code>&lt;a href=&quot;&quot; title=&quot;&quot;&gt; &lt;abbr title=&quot;&quot;&gt; &lt;acronym title=&quot;&quot;&gt; &lt;b&gt; &lt;blockquote cite=&quot;&quot;&gt; &lt;cite&gt; &lt;code&gt; &lt;del datetime=&quot;&quot;&gt; &lt;em&gt; &lt;i&gt; &lt;q cite=&quot;&quot;&gt; &lt;strike&gt; &lt;strong&gt; </code></small></p>-->
							<p>
								<textarea name="comment" id="comment" cols="58" rows="10" tabindex="4"></textarea>
							</p>
							<p>
								<input name="submit" id="submit" tabindex="5" value="Submit Comment" type="submit">
								<input name="comment_post_ID" value="13" id="comment_post_ID" type="hidden">
								<input name="comment_parent" id="comment_parent" value="0" type="hidden">
							</p>
						</form>
					</div>
				</div>
*/
?>

<?php
/**
 * The template for displaying Comments.
 *
 * The area of the page that contains both current comments
 * and the comment form. The actual display of comments is
 * handled by a callback to twentyeleven_comment() which is
 * located in the functions.php file.
 *
 * @package WordPress
 * @subpackage Mely Amaliah
 * @since Mely Amaliah 0.5
 */
?>
	<!-- grab comments on single pages -->
	<div class="comments">
	<?php // You can start editing here -- including this comment! ?>
	<?php if ( have_comments() ) : ?>
		<h3 id="comments">There's <?php comments_number( 'no responses', 'one response', '% responses' ); ?>. to “<?php the_title(); ?>”</h3>
		
		<?php if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) : // are there comments to navigate through ?>
		<div class="navigation">
			<div class="alignleft"><?php previous_comments_link( 'Older Comments' ); ?></div>
			<div class="alignright"><?php next_comments_link( 'Newer Comments' ); ?></div>
		</div>		
		<?php endif; // check for comment navigation ?>

		<ol class="commentlist">
			<?php
				/* Loop through and list the comments. Tell wp_list_comments()
				 * to use twentyeleven_comment() to format the comments.
				 * If you want to overload this in a child theme then you can
				 * define twentyeleven_comment() and that will be used instead.
				 * See twentyeleven_comment() in twentyeleven/functions.php for more.
				 */
				wp_list_comments( array( 'callback' => 'mely_comment' ) );
			?>
		</ol>

		<?php if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) : // are there comments to navigate through ?>
		<div class="navigation">
			<div class="alignleft"><?php previous_comments_link( __( '&larr; Older Comments', 'melyamaliah' ) ); ?></div>
			<div class="alignright"><?php next_comments_link( __( 'Newer Comments &rarr;', 'melyamaliah' ) ); ?></div>
		</div>		
		<?php endif; // check for comment navigation ?>

	<?php
		/* If there are no comments and comments are closed, let's leave a little note, shall we?
		 * But we don't want the note on pages or post types that do not support comments.
		 */
		elseif ( ! comments_open() && ! is_page() && post_type_supports( get_post_type(), 'comments' ) ) :
	?>		
	<?php endif; ?>
	
	<?php comment_form(); ?>
	
</div><!-- #comments -->
